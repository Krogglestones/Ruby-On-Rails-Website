
Rails.application.routes.draw do

  resources :add_nameto_users
  resources :comments

  resources :blogs do
    get 'page/:page', action: :index, on: :collection
    resources :comments
  end

  resources :add_newsletter_to_articles
  devise_for :tests
  devise_for :users

  resources :reviews
  resources :articles do
    get 'page/:page', action: :index, on: :collection
  end

  get 'email_article/:id', to: 'articles#email_article', as: 'email_article'

  get 'store', to: 'stores#index', as: 'store_index'
  get 'store/:id', to: 'stores#show', as: 'store_show'

  get 'puzzles/new'
  post 'puzzles/new', to: "puzzles#create"
  get 'puzzles/show'


  resources :products do
    get 'page/:page', action: :index, on: :collection
    resources :reviews
  end

  resources :restaurants
  get 'page/contact_us'

  get 'page/store'

  get 'page/preferences'

  get 'page/blog'


  get 'page/articles'

  get 'page/login'

  resources :movies
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  get 'page/calendar((/:month)/:year)',
      to: 'page#calendar',
      as: 'calendar'

  root 'stores#index'

end

