class AddNametoUser < ApplicationRecord
end
