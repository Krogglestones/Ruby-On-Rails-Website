class AddNewsletterToArticle < ApplicationRecord
end
