class Article < ApplicationRecord

  paginates_per 10

  validates_presence_of :title,
                        :author,
                        :publish_date,
                        # :published_or_not,
                        :content,
                        :thumbnail_avatar

  # order(:publish_date)

  after_save do |article|

    #check to see if its published
    #if (article.published?)

    User.where(:newsletter => true).each do |user|
      UserMailer.manual_email_and_new_email(user, article).deliver_now
    end
  end

end
