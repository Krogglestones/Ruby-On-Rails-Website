class Restaurant < ApplicationRecord
end
