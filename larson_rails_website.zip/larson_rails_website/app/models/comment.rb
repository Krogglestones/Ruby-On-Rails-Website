class Comment < ApplicationRecord
  belongs_to :blog

  validates :rating, numericality: { greater_than: 0, less_than: 6 }


end
