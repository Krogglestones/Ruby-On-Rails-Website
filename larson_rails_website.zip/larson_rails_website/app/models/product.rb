class Product < ApplicationRecord

  has_many :reviews, dependent: :destroy

  validates_presence_of :name, :description, :thumbnail_image, :Full_size_image

  validates_numericality_of :quantity_on_hand,
                            :selling_price,
                            :cost_of_product,
                            :shipping_weight

  #validates :name, uniqueness: true

  validates :quantity_on_hand, numericality: { greater_than: -1 }
  paginates_per 10

  # validates :rating, numericality: { greater_than: 0, less_than: 11 }

end
