class ApplicationMailer < ActionMailer::Base
  default from: 'crlarson68@gmail.com'
  layout 'mailer'
end
