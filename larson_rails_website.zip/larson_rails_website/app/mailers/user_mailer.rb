class UserMailer < ApplicationMailer

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.thank_you_email.subject
  #
  def thank_you_email(email_address)
    @greeting = "Hi"
    mail subject: 'Thank you',
                 to: email_address,
                 cc: 'crlarson68@gmail.com',
                 bcc: 'dave.jones@scc.spokane.edu'
  end

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.newsletter_email.subject
  #
  # def newsletter_email(user, article)
  #   @user = user
  #   @article = article
  #
  #   mail subject: article.title,
  #                to: user.email,
  #                bcc: 'dave.jones@scc.spokane.edu'
  # end

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.manual_email_and_new_email.subject
  #
  def manual_email_and_new_email(user, article)
      @user = user
      @article = article

      mail subject: article.title,
                   to: user.email,
                   bcc: 'dave.jones@scc.spokane.edu'
  end

end
