module PuzzlesHelper
end
