class Puzzle < Prawn::Document

  def initialize(puzzle_name, words)

    #call super because you're inheriting from Prawn
    super()

    font "Courier", :size => 24
    text puzzle_name, :align => :center
    font "Courier", :size => 10
    # text words

    word_list = words.split("\n")

    word_list.each_with_index do |word, index|
      word_list[index] = word.chomp
    end

    word_list.each do |word|
      text word
    end

  end

end