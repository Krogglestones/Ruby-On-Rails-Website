module ApplicationHelper


=begin
  def days_in_month(month, year = current.year)
    days_num = ("").to_i
    if month == 2 && ::Date.gregorian_leap?(year)
      29
    else
      COMMON_YEAR_DAYS_IN_MONTH[month]
    end
  end
=end

  def calendar(month, year)

    cal_str = ""
    first_day = Date.new(year, month).at_beginning_of_month.wday
    next_year = year + 1
    previous_year = year - 1
    next_month = month + 1
    prev_month = month - 1
    current_year = year

    if prev_month == 0
      prev_month = 12
    end
    if prev_month == 12
      current_year -= 1
    end

    if next_month == 13
      next_month = 1
      # if next_month == 2
      # end
    end

    cal_str += link_to "<<<<   ", calendar_path(month: prev_month, year: current_year)
    cal_str += link_to "    >>>>", calendar_path(month: next_month, year: 2017)
    # if prev_month == 0
    #   prev_month = 12
    #   if prev_month == 12
    #     current_year -= 1
    #   end
    # end



    # if next_month == 13
    #   next_month = 1
    # end
    # if month == 2
    #   year = next_year
    # end
    # cal_str += link_to "NEXT", page_calendar_path(month: next_month, year: current_year)

    cal_str += '<table>'
    cal_str += '<tr>'
   # cal_str += '<td>&nbsp;</td>'
    #cal_str += '<td>&nbsp;</td>'
    #cal_str += '<td>&nbsp;</td>'
    cal_str += '<td class="center_month" colspan="7">'
    cal_str += Date.new(year, month).strftime("%B %Y")
    cal_str += '</td>'
    #cal_str += '<td>&nbsp;</td>'
    #cal_str += '<td>&nbsp;</td>'
    #cal_str += '<td>&nbsp;</td>'
    cal_str += '</tr>'

    cal_str += '<tr>'
    cal_str += '<td>Sun</td>'
    cal_str += '<td>Mon</td>'
    cal_str += '<td>Tue</td>'
    cal_str += '<td>Wed</td>'
    cal_str += '<td>Thu</td>'
    cal_str += '<td>Fri</td>'
    cal_str += '<td>Sat</td>'
    cal_str += '</tr>'

    cal_str += '<tr>'
    first_day.times do
      cal_str += '<td>&nbsp;</td>'
    end
    (7 - first_day).times do |day|
      cal_str += '<td>'
      cal_str += (day + 1).to_s
      cal_str += '</td>'
    end
    cal_str += '</tr>'

    days = (7 - first_day)
    cal_str += '<tr>'
    7.times do
      cal_str += '<td>'
      cal_str += (days + 1).to_s
      days += 1
      cal_str += '</td>'
    end
    cal_str += '</tr>'

    cal_str += '<tr>'
    7.times do
      cal_str += '<td>'
      cal_str += (days + 1).to_s
      days += 1
      cal_str += '</td>'
    end
    cal_str += '</tr>'

    cal_str += '<tr>'
    7.times do
      cal_str += '<td>'
      cal_str += (days + 1).to_s
      days += 1
      cal_str += '</td>'
    end
    cal_str += '</tr>'

    # final week

    cal_str += '<tr>'
    if (month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12)
      total_days = 31
      remaining_days = total_days - days
    elsif (month == 4) || (month == 6) || (month == 9) || (month == 11)
      total_days = 30
      remaining_days = total_days - days
    elsif (month == 2) && (year % 4 == 0)
      total_days = 29
      remaining_days = total_days - days
    else
      total_days = 28
      remaining_days = total_days - days
    end
    empties = 7 - remaining_days
    if remaining_days <= 7
      remaining_days.times do
        cal_str += '<td>'
        cal_str += (days + 1).to_s
        days += 1
        remaining_days -= 1
        cal_str += '</td>'
      end
      empties.times do
        cal_str += '<td>&nbsp;'
        cal_str += '</td>'
      end
    elsif remaining_days > 7
      7.times do
        cal_str += '<td>'
        cal_str += (days + 1).to_s
        days += 1
        remaining_days -= 1
        cal_str += '</td>'
      end
    end
    cal_str += '</tr>'

    cal_str += '<tr>'
    if remaining_days > 0
      empties = 7 - remaining_days
      remaining_days.times do
        cal_str += '<td>'
        cal_str += (days + 1).to_s
        days += 1
        cal_str += '</td>'
      end
      empties.times do
        cal_str += '<td>&nbsp;'
        cal_str += '</td>'
      end
    end
    cal_str += '</tr>'

    cal_str += '</table>'


    return cal_str.html_safe

  end

end
