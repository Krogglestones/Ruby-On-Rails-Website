class StoresController < ApplicationController
  # before_action :set_store, only: [:show, :edit, :update, :destroy]
  # before_action :authenticate_admin, except:[:show, :index]
  # GET /stores
  # GET /stores.json
  def index
    @page = params[:page].to_i
    @products = Product.page(@page)
  end

  # GET /stores/1
  # GET /stores/1.json
  def show
    @product = Product.find(params[:id])
  end


end
