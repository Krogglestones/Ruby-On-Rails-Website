class AddNewsletterToArticlesController < ApplicationController
  before_action :set_add_newsletter_to_article, only: [:show, :edit, :update, :destroy]

  # GET /add_newsletter_to_articles
  # GET /add_newsletter_to_articles.json
  def index
    @add_newsletter_to_articles = AddNewsletterToArticle.all
  end

  # GET /add_newsletter_to_articles/1
  # GET /add_newsletter_to_articles/1.json
  def show
  end

  # GET /add_newsletter_to_articles/new
  def new
    @add_newsletter_to_article = AddNewsletterToArticle.new
  end

  # GET /add_newsletter_to_articles/1/edit
  def edit
  end

  # POST /add_newsletter_to_articles
  # POST /add_newsletter_to_articles.json
  def create
    @add_newsletter_to_article = AddNewsletterToArticle.new(add_newsletter_to_article_params)

    respond_to do |format|
      if @add_newsletter_to_article.save
        format.html { redirect_to @add_newsletter_to_article, notice: 'Add newsletter to article was successfully created.' }
        format.json { render :show, status: :created, location: @add_newsletter_to_article }
      else
        format.html { render :new }
        format.json { render json: @add_newsletter_to_article.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /add_newsletter_to_articles/1
  # PATCH/PUT /add_newsletter_to_articles/1.json
  def update
    respond_to do |format|
      if @add_newsletter_to_article.update(add_newsletter_to_article_params)
        format.html { redirect_to @add_newsletter_to_article, notice: 'Add newsletter to article was successfully updated.' }
        format.json { render :show, status: :ok, location: @add_newsletter_to_article }
      else
        format.html { render :edit }
        format.json { render json: @add_newsletter_to_article.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /add_newsletter_to_articles/1
  # DELETE /add_newsletter_to_articles/1.json
  def destroy
    @add_newsletter_to_article.destroy
    respond_to do |format|
      format.html { redirect_to add_newsletter_to_articles_url, notice: 'Add newsletter to article was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_add_newsletter_to_article
      @add_newsletter_to_article = AddNewsletterToArticle.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def add_newsletter_to_article_params
      params.require(:add_newsletter_to_article).permit(:newsletter)
    end
end
