
class PageController < ApplicationController

  def contact_us

    @first_name = params['first_name']
    @last_name = params['last_name']
    @email_address = params['email_address']
    @phone_number = params['phone_number']
    @question = params['question']
    @contact = params['contact']
    @items = ['Out', 'Of', 'Time,', 'Emails', 'Work', 'Though :)']
    @submit = params['commit']

    @subscribed = params['newsletter'] == 'subscribed' ? true : false
    @phone = params['phone'] == 'call_me' ? true : false

    @selected_item = params[@items]



    if @submit == 'Submit'

      UserMailer.thank_you_email(@email_address).deliver_now

      if (@first_name == nil?) || (@first_name == '')
        flash.now[:error] = "#{flash.now[:error]}<br/>&nbsp;&nbsp;&nbsp;&nbsp;First name is required."
      end
      if (@last_name == nil?) || (@last_name == '')
        flash.now[:error] = "#{flash.now[:error]}<br/>&nbsp;&nbsp;&nbsp;&nbsp;Last name is required."
      end
      if (@email_address == nil?) || (@email_address == '')
        flash.now[:error] = "#{flash.now[:error]}<br/>&nbsp;&nbsp;&nbsp;&nbsp;Email address is required."
      end

    end

  end

  def products
    # @products = products.name
    # @stuff = []
    # @products.each do |product|
    #   @stuff << product
    # end
  end

  def preferences
  end

  def blog
  end

  def calendar

    @month = params[:month].to_i
    if @month == 0
      @month = Time.now.month
    end
    @year = params[:year].to_i
    if @year == 0
      @year = Time.now.year
    end

  end

  def articles
  end

  def login
  end
end
