class CommentsController < ApplicationController
  before_action :set_comment, only: [:show, :edit, :update, :destroy]




  # POST /comments
  # POST /comments.json
  def create
    @blog = Blog.find(params[:blog_id])
    @comment = @blog.comments.create(comment_params)

    @comment.save
    redirect_to blogs_path(@blog.id)

  end


  # DELETE /comments/1
  # DELETE /comments/1.json
  def destroy
    @blog = Blog.find(params[:blog_id])
    @comment = @blog.comments.find(params[:id])
    @comment.destroy
    redirect_to blog_path(@blog.id)
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_comment
      @comment = Comment.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def comment_params
      params.require(:comment).permit(:author, :content, :avatar, :rating, :blog_id)
    end
end
