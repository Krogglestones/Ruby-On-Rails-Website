# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


include Faker


# 100.times do
#   product = Product.create(
#       name: Beer.name,
#       description: Beer.style,
#       quantity_on_hand: rand(1..100),
#       selling_price: rand(2.0..200.0),
#       cost_of_product: rand(1..100),
#       shipping_weight: rand(1.0..20.0),
#       thumbnail_image: "http://lorempixel.com/35/35/cats",
#       Full_size_image: "http://lorempixel.com/480/480/cats"
#   )
#   rand(1..10).times do
#     product.reviews.create(
#                        author: Name.first_name,
#                        comment: Lorem.paragraph,
#                        rating: rand(1..10)
#     )
#   end
# end
# Product.destroy_all


#---------------------------------------------------------------

# 100.times do
#   article = Article.create(
#       title: Book.title,
#       author: Faker::Name.name,
#       publish_date: Faker::Date.backward(3000),
#       published_or_not: Boolean.boolean(0.5),
#       content: Lorem.sentences(10),
#       thumbnail_avatar: "http://lorempixel.com/50/50/people"
#   )
# end
# Article.destroy_all

# ---------------------------------------------------------------

# Blog.destroy_all
100.times do
  blog = Blog.create(
      title: Food.dish,
      published_date: Faker::Time.between(2000.days.ago, Date.today, :all),
      author: Faker::FamilyGuy.character,
      content: Faker::Lorem.paragraph(15)
  )
  rand(1..10).times do
    blog.comments.create(
        author: Name.first_name,
        content: Lorem.paragraph,
        avatar: "http://lorempixel.com/50/50/people",
        rating: rand(1..5)
    )
  end
end


