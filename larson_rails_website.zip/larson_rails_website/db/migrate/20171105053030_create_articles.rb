class CreateArticles < ActiveRecord::Migration[5.1]
  def change
    create_table :articles do |t|
      t.string :title
      t.string :author
      t.date :publish_date
      t.boolean :published_or_not
      t.text :content
      t.string :thumbnail_avatar

      t.timestamps
    end
  end
end
