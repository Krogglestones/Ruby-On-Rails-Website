class CreateAddNewsletterToArticles < ActiveRecord::Migration[5.1]
  def change
    create_table :add_newsletter_to_articles do |t|
      t.boolean :newsletter

      t.timestamps
    end
  end
end
