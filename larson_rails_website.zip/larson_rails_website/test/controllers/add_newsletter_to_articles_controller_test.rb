require 'test_helper'

class AddNewsletterToArticlesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @add_newsletter_to_article = add_newsletter_to_articles(:one)
  end

  test "should get index" do
    get add_newsletter_to_articles_url
    assert_response :success
  end

  test "should get new" do
    get new_add_newsletter_to_article_url
    assert_response :success
  end

  test "should create add_newsletter_to_article" do
    assert_difference('AddNewsletterToArticle.count') do
      post add_newsletter_to_articles_url, params: { add_newsletter_to_article: { newsletter: @add_newsletter_to_article.newsletter } }
    end

    assert_redirected_to add_newsletter_to_article_url(AddNewsletterToArticle.last)
  end

  test "should show add_newsletter_to_article" do
    get add_newsletter_to_article_url(@add_newsletter_to_article)
    assert_response :success
  end

  test "should get edit" do
    get edit_add_newsletter_to_article_url(@add_newsletter_to_article)
    assert_response :success
  end

  test "should update add_newsletter_to_article" do
    patch add_newsletter_to_article_url(@add_newsletter_to_article), params: { add_newsletter_to_article: { newsletter: @add_newsletter_to_article.newsletter } }
    assert_redirected_to add_newsletter_to_article_url(@add_newsletter_to_article)
  end

  test "should destroy add_newsletter_to_article" do
    assert_difference('AddNewsletterToArticle.count', -1) do
      delete add_newsletter_to_article_url(@add_newsletter_to_article)
    end

    assert_redirected_to add_newsletter_to_articles_url
  end
end
