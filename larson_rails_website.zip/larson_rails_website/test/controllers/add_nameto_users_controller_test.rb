require 'test_helper'

class AddNametoUsersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @add_nameto_user = add_nameto_users(:one)
  end

  test "should get index" do
    get add_nameto_users_url
    assert_response :success
  end

  test "should get new" do
    get new_add_nameto_user_url
    assert_response :success
  end

  test "should create add_nameto_user" do
    assert_difference('AddNametoUser.count') do
      post add_nameto_users_url, params: { add_nameto_user: { first_name: @add_nameto_user.first_name, last_name: @add_nameto_user.last_name } }
    end

    assert_redirected_to add_nameto_user_url(AddNametoUser.last)
  end

  test "should show add_nameto_user" do
    get add_nameto_user_url(@add_nameto_user)
    assert_response :success
  end

  test "should get edit" do
    get edit_add_nameto_user_url(@add_nameto_user)
    assert_response :success
  end

  test "should update add_nameto_user" do
    patch add_nameto_user_url(@add_nameto_user), params: { add_nameto_user: { first_name: @add_nameto_user.first_name, last_name: @add_nameto_user.last_name } }
    assert_redirected_to add_nameto_user_url(@add_nameto_user)
  end

  test "should destroy add_nameto_user" do
    assert_difference('AddNametoUser.count', -1) do
      delete add_nameto_user_url(@add_nameto_user)
    end

    assert_redirected_to add_nameto_users_url
  end
end
