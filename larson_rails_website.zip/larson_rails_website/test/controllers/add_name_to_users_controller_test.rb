require 'test_helper'

class AddNameToUsersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @add_name_to_user = add_name_to_users(:one)
  end

  test "should get index" do
    get add_name_to_users_url
    assert_response :success
  end

  test "should get new" do
    get new_add_name_to_user_url
    assert_response :success
  end

  test "should create add_name_to_user" do
    assert_difference('AddNameToUser.count') do
      post add_name_to_users_url, params: { add_name_to_user: { first_name: @add_name_to_user.first_name, last_name: @add_name_to_user.last_name } }
    end

    assert_redirected_to add_name_to_user_url(AddNameToUser.last)
  end

  test "should show add_name_to_user" do
    get add_name_to_user_url(@add_name_to_user)
    assert_response :success
  end

  test "should get edit" do
    get edit_add_name_to_user_url(@add_name_to_user)
    assert_response :success
  end

  test "should update add_name_to_user" do
    patch add_name_to_user_url(@add_name_to_user), params: { add_name_to_user: { first_name: @add_name_to_user.first_name, last_name: @add_name_to_user.last_name } }
    assert_redirected_to add_name_to_user_url(@add_name_to_user)
  end

  test "should destroy add_name_to_user" do
    assert_difference('AddNameToUser.count', -1) do
      delete add_name_to_user_url(@add_name_to_user)
    end

    assert_redirected_to add_name_to_users_url
  end
end
