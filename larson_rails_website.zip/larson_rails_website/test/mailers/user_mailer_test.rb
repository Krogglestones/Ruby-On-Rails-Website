require 'test_helper'

class UserMailerTest < ActionMailer::TestCase
  test "thank_you_email" do
    mail = UserMailer.thank_you_email
    assert_equal "Thank you email", mail.subject
    assert_equal ["to@example.org"], mail.to
    assert_equal ["from@example.com"], mail.from
    assert_match "Hi", mail.body.encoded
  end

  test "newsletter_email" do
    mail = UserMailer.newsletter_email
    assert_equal "Newsletter email", mail.subject
    assert_equal ["to@example.org"], mail.to
    assert_equal ["from@example.com"], mail.from
    assert_match "Hi", mail.body.encoded
  end

  test "manual_email_and_new_email" do
    mail = UserMailer.manual_email_and_new_email
    assert_equal "Manual email and new email", mail.subject
    assert_equal ["to@example.org"], mail.to
    assert_equal ["from@example.com"], mail.from
    assert_match "Hi", mail.body.encoded
  end

end
