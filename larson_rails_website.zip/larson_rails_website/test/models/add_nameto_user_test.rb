require 'test_helper'

class AddNametoUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
