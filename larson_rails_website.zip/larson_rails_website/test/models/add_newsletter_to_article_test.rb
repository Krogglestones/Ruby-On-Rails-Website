require 'test_helper'

class AddNewsletterToArticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
