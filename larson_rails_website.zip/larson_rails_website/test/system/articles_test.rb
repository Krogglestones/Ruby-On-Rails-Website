require "application_system_test_case"

class ArticlesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit articles_url
  #
  #   assert_selector "h1", text: "Article"
  # end
end
