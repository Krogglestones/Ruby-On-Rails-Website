require "application_system_test_case"

class AddNewsletterToArticlesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit add_newsletter_to_articles_url
  #
  #   assert_selector "h1", text: "AddNewsletterToArticle"
  # end
end
