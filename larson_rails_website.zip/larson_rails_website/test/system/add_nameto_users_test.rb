require "application_system_test_case"

class AddNametoUsersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit add_nameto_users_url
  #
  #   assert_selector "h1", text: "AddNametoUser"
  # end
end
